import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  ChevronLeftIcon, 
  ChevronRightIcon,
  CheckIcon,
  FireIcon,
  BeakerIcon,
  CloudIcon
} from '@heroicons/react/24/outline';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { getPrakritiPrediction } from '../services/api';
import { supabase } from '../lib/supabase';
import { prakritiQuestions } from '../data/prakritiQuestions';
import toast from 'react-hot-toast';

export const Prakriti: React.FC = () => {
  const { user } = useAuth();
  const { t, language } = useLanguage();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [results, setResults] = useState<any>(null);

  const handleAnswer = (optionIndex: number) => {
    const newAnswers = [...answers];
    newAnswers[currentQuestion] = optionIndex;
    setAnswers(newAnswers);
  };

  const goToNextQuestion = () => {
    if (currentQuestion < prakritiQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    }
  };

  const goToPreviousQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const calculateResults = async () => {
    if (answers.length !== prakritiQuestions.length) {
      toast.error('Please answer all questions');
      return;
    }

    setIsLoading(true);
    try {
      // Calculate scores based on answers
      const scores = answers.map((answerIndex, questionIndex) => {
        const question = prakritiQuestions[questionIndex];
        const selectedOption = question.options[answerIndex];
        return selectedOption ? selectedOption.score : { vata: 0, pitta: 0, kapha: 0 };
      });

      const totalScores = scores.reduce(
        (acc, score) => ({
          vata: acc.vata + score.vata,
          pitta: acc.pitta + score.pitta,
          kapha: acc.kapha + score.kapha,
        }),
        { vata: 0, pitta: 0, kapha: 0 }
      );

      const answerValues = answers.map((answerIndex, questionIndex) => {
        const question = prakritiQuestions[questionIndex];
        const selectedOption = question.options[answerIndex];
        return selectedOption ? selectedOption.score.vata + selectedOption.score.pitta + selectedOption.score.kapha : 0;
      });

      const prediction = await getPrakritiPrediction(answerValues);

      // Save to database
      const { data, error } = await supabase
        .from('prakriti_results')
        .insert([
          {
            user_id: user?.id,
            vata_score: prediction.vata_score,
            pitta_score: prediction.pitta_score,
            kapha_score: prediction.kapha_score,
            dominant_dosha: prediction.dominant_dosha,
            recommendations: prediction.recommendations,
          },
        ])
        .select()
        .single();

      if (error) throw error;

      setResults(data);
      setShowResults(true);
    } catch (error) {
      console.error('Error calculating results:', error);
      toast.error('Failed to calculate results. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const getDoshaIcon = (dosha: string) => {
    switch (dosha.toLowerCase()) {
      case 'vata':
        return <CloudIcon className="w-8 h-8" />;
      case 'pitta':
        return <FireIcon className="w-8 h-8" />;
      case 'kapha':
        return <BeakerIcon className="w-8 h-8" />;
      default:
        return null;
    }
  };

  const getDoshaColor = (dosha: string) => {
    switch (dosha.toLowerCase()) {
      case 'vata':
        return 'bg-blue-500';
      case 'pitta':
        return 'bg-red-500';
      case 'kapha':
        return 'bg-green-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getDoshaDescription = (dosha: string) => {
    const descriptions = {
      Vata: 'Vata represents the principle of movement and governs breathing, blinking, muscle movement, and heartbeat. People with dominant Vata tend to be creative, energetic, and quick-thinking.',
      Pitta: 'Pitta represents metabolism and transformation. It governs digestion, absorption, and body temperature. People with dominant Pitta tend to be intelligent, goal-oriented, and natural leaders.',
      Kapha: 'Kapha represents structure and stability. It governs growth, immunity, and strength. People with dominant Kapha tend to be calm, stable, and nurturing.'
    };
    return descriptions[dosha as keyof typeof descriptions] || '';
  };

  if (showResults && results) {
    return (
      <div className="max-w-4xl mx-auto p-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckIcon className="w-10 h-10 text-green-600" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Your Prakriti Results</h1>
          <p className="text-gray-600">
            Your dominant dosha has been identified. Follow the recommendations below for optimal health.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Dosha Scores */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white rounded-2xl border border-gray-200 p-8"
          >
            <h2 className="text-xl font-semibold text-gray-900 mb-6">Dosha Composition</h2>
            
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <CloudIcon className="w-6 h-6 text-blue-600" />
                  <span className="font-medium text-gray-900">Vata</span>
                </div>
                <span className="font-semibold text-gray-900">{results.vata_score}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div 
                  className="bg-blue-500 h-3 rounded-full transition-all duration-1000" 
                  style={{ width: `${results.vata_score}%` }}
                ></div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <FireIcon className="w-6 h-6 text-red-600" />
                  <span className="font-medium text-gray-900">Pitta</span>
                </div>
                <span className="font-semibold text-gray-900">{results.pitta_score}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div 
                  className="bg-red-500 h-3 rounded-full transition-all duration-1000" 
                  style={{ width: `${results.pitta_score}%` }}
                ></div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <BeakerIcon className="w-6 h-6 text-green-600" />
                  <span className="font-medium text-gray-900">Kapha</span>
                </div>
                <span className="font-semibold text-gray-900">{results.kapha_score}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div 
                  className="bg-green-500 h-3 rounded-full transition-all duration-1000" 
                  style={{ width: `${results.kapha_score}%` }}
                ></div>
              </div>
            </div>

            <div className="mt-8 p-6 bg-gradient-to-r from-green-50 to-blue-50 rounded-xl">
              <div className="flex items-center space-x-3 mb-3">
                {getDoshaIcon(results.dominant_dosha)}
                <h3 className="text-xl font-bold text-gray-900">
                  Your Dominant Dosha: {results.dominant_dosha}
                </h3>
              </div>
              <p className="text-gray-700 text-sm leading-relaxed">
                {getDoshaDescription(results.dominant_dosha)}
              </p>
            </div>
          </motion.div>

          {/* Recommendations */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white rounded-2xl border border-gray-200 p-8"
          >
            <h2 className="text-xl font-semibold text-gray-900 mb-6">Personalized Recommendations</h2>
            
            <div className="space-y-4">
              {results.recommendations.map((recommendation: string, index: number) => (
                <div key={index} className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <CheckIcon className="w-3 h-3 text-green-600" />
                  </div>
                  <p className="text-gray-700">{recommendation}</p>
                </div>
              ))}
            </div>

            <div className="mt-8 p-6 bg-yellow-50 rounded-xl">
              <h4 className="font-semibold text-yellow-800 mb-2">Important Note</h4>
              <p className="text-yellow-700 text-sm">
                These recommendations are based on traditional Ayurvedic principles. 
                For personalized treatment, consult with a qualified Ayurvedic practitioner.
              </p>
            </div>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-center mt-8"
        >
          <button
            onClick={() => {
              setShowResults(false);
              setCurrentQuestion(0);
              setAnswers([]);
              setResults(null);
            }}
            className="bg-green-600 text-white px-8 py-3 rounded-xl font-semibold hover:bg-green-700 transition-colors"
          >
            Take Test Again
          </button>
        </motion.div>
      </div>
    );
  }

  const question = prakritiQuestions[currentQuestion];
  const progress = ((currentQuestion + 1) / prakritiQuestions.length) * 100;

  return (
    <div className="max-w-4xl mx-auto p-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-8"
      >
        <h1 className="text-3xl font-bold text-gray-900 mb-4">{t('prakritiTest')}</h1>
        <p className="text-gray-600 mb-6">
          Answer the following questions to discover your Ayurvedic constitution
        </p>
        
        {/* Progress Bar */}
        <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
          <motion.div 
            className="bg-green-600 h-2 rounded-full"
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.3 }}
          />
        </div>
        <p className="text-sm text-gray-500">
          Question {currentQuestion + 1} of {prakritiQuestions.length}
        </p>
      </motion.div>

      {/* Question Card */}
      <motion.div
        key={currentQuestion}
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: -20 }}
        className="bg-white rounded-2xl border border-gray-200 p-8 mb-8"
      >
        <h2 className="text-xl font-semibold text-gray-900 mb-6">
          {language === 'en' ? question.question_en : question.question_hi}
        </h2>
        
        <div className="space-y-4">
          {question.options.map((option, index) => (
            <button
              key={index}
              onClick={() => handleAnswer(index)}
              className={`w-full p-4 text-left rounded-xl border-2 transition-all ${
                answers[currentQuestion] === index
                  ? 'border-green-600 bg-green-50'
                  : 'border-gray-200 hover:border-green-300 hover:bg-gray-50'
              }`}
            >
              <div className="flex items-center space-x-3">
                <div className={`w-4 h-4 rounded-full border-2 ${
                  answers[currentQuestion] === index
                    ? 'border-green-600 bg-green-600'
                    : 'border-gray-300'
                }`}>
                  {answers[currentQuestion] === index && (
                    <CheckIcon className="w-3 h-3 text-white" />
                  )}
                </div>
                <span className="text-gray-900">
                  {language === 'en' ? option.text_en : option.text_hi}
                </span>
              </div>
            </button>
          ))}
        </div>
      </motion.div>

      {/* Navigation */}
      <div className="flex justify-between items-center">
        <button
          onClick={goToPreviousQuestion}
          disabled={currentQuestion === 0}
          className="flex items-center space-x-2 px-6 py-3 text-gray-600 hover:text-gray-900 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          <ChevronLeftIcon className="w-5 h-5" />
          <span>{t('previousQuestion')}</span>
        </button>

        {currentQuestion === prakritiQuestions.length - 1 ? (
          <button
            onClick={calculateResults}
            disabled={answers[currentQuestion] === undefined || isLoading}
            className="flex items-center space-x-2 bg-green-600 text-white px-8 py-3 rounded-xl font-semibold hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            {isLoading ? (
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
            ) : (
              <CheckIcon className="w-5 h-5" />
            )}
            <span>{isLoading ? 'Calculating...' : t('completeTest')}</span>
          </button>
        ) : (
          <button
            onClick={goToNextQuestion}
            disabled={answers[currentQuestion] === undefined}
            className="flex items-center space-x-2 bg-green-600 text-white px-6 py-3 rounded-xl font-semibold hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            <span>{t('nextQuestion')}</span>
            <ChevronRightIcon className="w-5 h-5" />
          </button>
        )}
      </div>
    </div>
  );
};