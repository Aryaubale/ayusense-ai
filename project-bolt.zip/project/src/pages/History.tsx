import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { 
  ClockIcon, 
  ChatBubbleLeftRightIcon, 
  DocumentTextIcon,
  ChartBarIcon,
  CalendarIcon
} from '@heroicons/react/24/outline';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { supabase } from '../lib/supabase';
import { ChatMessage, PrakritiResult } from '../types';
import { format } from 'date-fns';

export const History: React.FC = () => {
  const { user } = useAuth();
  const { t } = useLanguage();
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [prakritiHistory, setPrakritiHistory] = useState<PrakritiResult[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'chats' | 'prakriti'>('chats');

  useEffect(() => {
    if (user) {
      loadHistory();
    }
  }, [user]);

  const loadHistory = async () => {
    setLoading(true);
    try {
      // Load chat history
      const { data: chats } = await supabase
        .from('chat_messages')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });

      if (chats) setChatHistory(chats);

      // Load Prakriti history
      const { data: prakriti } = await supabase
        .from('prakriti_results')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });

      if (prakriti) setPrakritiHistory(prakriti);
    } catch (error) {
      console.error('Error loading history:', error);
    } finally {
      setLoading(false);
    }
  };

  const groupChatsByDate = (chats: ChatMessage[]) => {
    const groups: { [key: string]: ChatMessage[] } = {};
    
    chats.forEach(chat => {
      const date = format(new Date(chat.created_at), 'yyyy-MM-dd');
      if (!groups[date]) {
        groups[date] = [];
      }
      groups[date].push(chat);
    });

    return Object.entries(groups).sort(([a], [b]) => b.localeCompare(a));
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold text-gray-900 mb-2">{t('history')}</h1>
        <p className="text-gray-600">
          Review your past consultations and assessments
        </p>
      </motion.div>

      {/* Tabs */}
      <div className="mb-8">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8">
            <button
              onClick={() => setActiveTab('chats')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'chats'
                  ? 'border-green-500 text-green-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <div className="flex items-center space-x-2">
                <ChatBubbleLeftRightIcon className="w-5 h-5" />
                <span>Chat History ({chatHistory.length})</span>
              </div>
            </button>
            <button
              onClick={() => setActiveTab('prakriti')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'prakriti'
                  ? 'border-green-500 text-green-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <div className="flex items-center space-x-2">
                <DocumentTextIcon className="w-5 h-5" />
                <span>Prakriti Assessments ({prakritiHistory.length})</span>
              </div>
            </button>
          </nav>
        </div>
      </div>

      {/* Content */}
      <div className="space-y-8">
        {activeTab === 'chats' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-8"
          >
            {chatHistory.length === 0 ? (
              <div className="text-center py-12 bg-white rounded-2xl border border-gray-200">
                <ChatBubbleLeftRightIcon className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No Chat History</h3>
                <p className="text-gray-500 mb-6">
                  Start a conversation with our AI to see your chat history here.
                </p>
              </div>
            ) : (
              groupChatsByDate(chatHistory).map(([date, chats]) => (
                <div key={date} className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
                  <div className="bg-gray-50 px-6 py-4 border-b border-gray-200">
                    <div className="flex items-center space-x-2">
                      <CalendarIcon className="w-5 h-5 text-gray-500" />
                      <h3 className="text-lg font-medium text-gray-900">
                        {format(new Date(date), 'MMMM d, yyyy')}
                      </h3>
                      <span className="text-sm text-gray-500">
                        ({chats.length} conversation{chats.length !== 1 ? 's' : ''})
                      </span>
                    </div>
                  </div>
                  <div className="divide-y divide-gray-100">
                    {chats.map((chat) => (
                      <div key={chat.id} className="p-6 hover:bg-gray-50 transition-colors">
                        <div className="flex items-start space-x-4">
                          <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                            <ChatBubbleLeftRightIcon className="w-4 h-4 text-green-600" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-gray-900 mb-2">
                              {chat.message}
                            </p>
                            <p className="text-sm text-gray-600 mb-3 line-clamp-3">
                              {chat.response}
                            </p>
                            <div className="flex items-center text-xs text-gray-500">
                              <ClockIcon className="w-3 h-3 mr-1" />
                              {format(new Date(chat.created_at), 'h:mm a')}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))
            )}
          </motion.div>
        )}

        {activeTab === 'prakriti' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            {prakritiHistory.length === 0 ? (
              <div className="text-center py-12 bg-white rounded-2xl border border-gray-200">
                <DocumentTextIcon className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No Assessments</h3>
                <p className="text-gray-500 mb-6">
                  Take the Prakriti assessment to see your results here.
                </p>
              </div>
            ) : (
              prakritiHistory.map((result) => (
                <div
                  key={result.id}
                  className="bg-white rounded-2xl border border-gray-200 p-6"
                >
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                        <ChartBarIcon className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900">
                          Prakriti Assessment
                        </h3>
                        <p className="text-sm text-gray-500">
                          {format(new Date(result.created_at), 'MMMM d, yyyy • h:mm a')}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-gray-500">Dominant Dosha</p>
                      <p className="text-lg font-semibold text-gray-900">
                        {result.dominant_dosha}
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-6 mb-6">
                    <div className="text-center">
                      <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
                        <div 
                          className="bg-blue-500 h-2 rounded-full" 
                          style={{ width: `${result.vata_score}%` }}
                        ></div>
                      </div>
                      <p className="text-sm font-medium text-gray-900">Vata</p>
                      <p className="text-xs text-gray-500">{result.vata_score}%</p>
                    </div>
                    <div className="text-center">
                      <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
                        <div 
                          className="bg-red-500 h-2 rounded-full" 
                          style={{ width: `${result.pitta_score}%` }}
                        ></div>
                      </div>
                      <p className="text-sm font-medium text-gray-900">Pitta</p>
                      <p className="text-xs text-gray-500">{result.pitta_score}%</p>
                    </div>
                    <div className="text-center">
                      <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
                        <div 
                          className="bg-green-500 h-2 rounded-full" 
                          style={{ width: `${result.kapha_score}%` }}
                        ></div>
                      </div>
                      <p className="text-sm font-medium text-gray-900">Kapha</p>
                      <p className="text-xs text-gray-500">{result.kapha_score}%</p>
                    </div>
                  </div>

                  <div className="bg-gray-50 rounded-xl p-4">
                    <h4 className="text-sm font-medium text-gray-900 mb-3">
                      Key Recommendations
                    </h4>
                    <div className="space-y-2">
                      {result.recommendations.slice(0, 3).map((rec: string, index: number) => (
                        <div key={index} className="flex items-start space-x-2">
                          <div className="w-1 h-1 bg-green-600 rounded-full mt-2 flex-shrink-0"></div>
                          <p className="text-sm text-gray-600">{rec}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))
            )}
          </motion.div>
        )}
      </div>
    </div>
  );
};